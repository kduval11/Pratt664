all_classes = ['Human-Information Behavior','Research Mthds/Law Lit','Strategic Leadership','Conservation and Preservation','Info Services & Resources', 'Information Arch/Inter Design','Information Professions','Acad Libraries and Scholarly','Usability Theory & Practice','Mgmt of Archives/Sp Collection','Government Info Sources','Library Media Centers','Mgmt of Archives/Sp Collection','Information Science Research']


#print the 3rd and 4th class from my list

#output sample (note this is not the correct output, I printed the 1st and 2nd):

# ❯ python3 pratt_schedule1.py
# Human-Information Behavior
# Research Mthds/Law Lit

